<?xml version='1.0' encoding='UTF-8'?>
<feed xmlns:yt="http://www.youtube.com/xml/schemas/2015" xmlns="http://www.w3.org/2005/Atom">
  <link rel="hub" href="https://pubsubhubbub.appspot.com" />
  <link rel="self" href="https://www.youtube.com/xml/feeds/videos.xml?channel_id=UCtEorrVfo4GQsN82HsrnKyk" />
  <title>YouTube video feed</title>
  <updated>2019-04-12T17:03:59.36824996+00:00</updated>
<entry>
  <id>yt:video:N2I_M7iPLc8</id>
  <yt:videoId>N2I_M7iPLc8</yt:videoId>
  <yt:channelId>UCEiwa5MRvm0mV85wpLTLUBw</yt:channelId>
  <title>تفصيل دقيق بخصوص اغنيه ملعون ابو العشق</title>
  <link rel="alternate" href="https://www.youtube.com/watch?v=N2I_M7iPLc8"/>
  <author>
   <name>Sobhi Mohammad - صبحي محمد</name>
   <uri>https://www.youtube.com/channel/UCEiwa5MRvm0mV85wpLTLUBw</uri>
  </author>
  <published>2019-04-12T17:01:21+00:00</published>
  <updated>2019-04-12T17:03:59.36824996+00:00</updated>
 </entry>
</feed>
