<?php
// simple example for the PHP pubsubhubbub Subscriber
// as defined at http://code.google.com/p/pubsubhubbub/
// written by Josh Fraser | joshfraser.com | josh@eventvue.com
// Released under Apache License 2.0
include("./src/Subscriber.php");
use \Pubsubhubbub\Subscriber\Subscriber;
$hub_url = "http://pubsubhubbub.appspot.com";
$callback_url = "https://kayali-net.000webhostapp.com/pubsubhubbub/sobhi_mohammad/youtube_subscribe_callback.php";
$feed = "https://www.youtube.com/xml/feeds/videos.xml?channel_id=UCEiwa5MRvm0mV85wpLTLUBw";
// create a new subscriber
$s = new Subscriber($hub_url, $callback_url);
// subscribe to a feed
$s->subscribe($feed);
