<?php


// Firebase API Key
define('FIREBASE_API_KEY', 'AAAAbHjxhJ4:APA91bGML1GmnEzEUxrUWfwDm_Vyc7uofcQWAfBCJXmruGNf3SVIawXV6rrkTVT4fbL-_oLwXtzxtz-oIwj2vQ9f7FmFClHRCIh6XxMkaz0rhu1_Nx2ROB04PUGhTR7gLwwhWI9zch1G');
