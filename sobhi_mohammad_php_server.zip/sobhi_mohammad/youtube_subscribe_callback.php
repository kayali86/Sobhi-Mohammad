<?php

    if (isset($_GET['hub_challenge']))
    {
        $challenge_time = date("M,d,Y h:i:s A") . "\n"; 
        file_put_contents('log.php', file_get_contents('php://input') . $challenge_time);
        echo $_REQUEST['hub_challenge'];
    }
    
    else
    {
        file_put_contents('video.php', file_get_contents('php://input'));
        $video = parseYoutubeUpdate(file_get_contents('php://input'));
        
        require_once __DIR__ . '/firebase/firebase.php';
        require_once __DIR__ . '/firebase/push.php';
        
        $firebase = new Firebase();
        $push = new Push();
        $push->setPayload($video);

        $json = $push->getPush();

            $topic = 'new_video';
            
            $response = $firebase->sendToTopic($topic, $json);
    }
    
    function parseYoutubeUpdate($data) {
        $xml = simplexml_load_string($data, 'SimpleXMLElement', LIBXML_NOCDATA);
        $video_id = substr((string)$xml->entry->id, 9);
        $channel_id = substr((string)$xml->entry->author->uri, 32);
        $title = (string)$xml->entry->title;
        $author = (string)$xml->entry->author->name;
        $published = (string)$xml->entry->published;
        $updated = (string)$xml->entry->updated;

        return array(
            'video_id'=>$video_id,
            'channel_id'=>$channel_id,
            'title'=>$title,
            'author'=>$author,
            'published'=>$published,
            'updated'=>$updated
        );
    }
    
